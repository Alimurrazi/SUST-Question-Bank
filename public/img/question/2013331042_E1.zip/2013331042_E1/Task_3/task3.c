#include<stdio.h>
#include<string.h>

int main()
{
	freopen("input1.txt","r",stdin);
	freopen("output1.txt","w",stdout);
	
	char str[100];
	char str1[100];
	
	int i,space,newline,j;
	
	while(gets(str))
	{
	 space=0,newline=0,j=0;	
    // printf("%s",str);
     if(strlen(str)==0)
     continue;		 
     for(i=0;i<strlen(str);i++)
	 {
		 if(str[i]==' ')
			space++;
		if(space>1)
			continue;
      str1[j++]=str[i];		
			 
	 }
	 str1[j]='\0';
	 printf("%s",str1);
	// printf("\n");

	}
}