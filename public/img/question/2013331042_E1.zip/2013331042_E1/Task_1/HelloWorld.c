//#include<stdio.h>
int main()
{
	int a=10;
  //	printf(" Hello   World");
	//single comment;
	/*
	  this is multilne comment;
	*/
	return 0;
}