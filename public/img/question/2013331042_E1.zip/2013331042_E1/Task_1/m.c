//#include<h.h>
#include<stdio.h>

int main()
{
	int a=4;
	int s=sqr(a);
	printf("%d\n",s);
	return 0;
}