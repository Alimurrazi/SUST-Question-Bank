int sqr(int n)
{
	return n*n;
}