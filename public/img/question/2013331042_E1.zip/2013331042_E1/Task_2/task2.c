#include<stdio.h>
#include<string.h>

int main()
{
	freopen("input1.txt","r",stdin);
	freopen("output1.txt","w",stdout);
	
	char str[100];
	
	int i;
	
	while(scanf("%s",&str)==1)
	{   if(strcmp(str,"for")==0 || strcmp(str,"while")==0 || strcmp(str,"switch")==0 || strcmp(str,"int")==0 || strcmp(str,"long")==0 || strcmp(str,"short")==0 || strcmp(str,"float")==0 || strcmp(str,"double")==0 || strcmp(str,"long long")==0 || strcmp(str,"return")==0)
		{
			printf("Not Valid\n");
            continue;			
		}
		if(str[0]=='_'||(str[0]>='a'&& str[0]<='z')||(str[0]>='A'&& str[0]<='Z'))
		{	
		for(i=0;i<strlen(str);i++)
		{
			
			if(str[i]==' '||str[i]=='&'||str[i]=='$'||str[i]=='%')
			break;
		}
		if(i==strlen(str))
			printf("Valid\n");
		else
			printf("Not Valid\n");
		}
		else
		printf("Not Valid\n");	
	//	printf("\n");
	//	printf("%s",str);
	}
}